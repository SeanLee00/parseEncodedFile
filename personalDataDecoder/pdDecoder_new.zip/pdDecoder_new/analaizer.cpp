#include "analaizer.h"
#include "PrivateData.h"
#include <QRegularExpression>

namespace {
uint GetLengthIndex(const QByteArray&line) {
    return line.lastIndexOf(QByteArrayView("ECU1")) - 1;
}

int getPayloadSizeIndex(const QByteArray&line) {
    auto result = line.lastIndexOf('\0', line.size() - 2) - 1;
    return result;
}

int getPayloadSize(const QByteArray&line) {
    int index = getPayloadSizeIndex(line);
    return index > 0 ? (index < line.size() ? static_cast<int8_t>(line[index]) : index) : index;
}

QByteArray updatePayload(const QByteArray &input) {
    int pos = -1;
    int newPosStart = -1;
    int newPosEnd = -1;
    bool isReplaced = false;
    QString line(input);
    QString etext;
    do {
        newPosStart = input.indexOf('{', pos + 1);
        if (newPosStart > 0 && input[newPosStart - 1] == 'p' && input[newPosStart + 1] == 'd') {
            pos = newPosStart;
            newPosEnd = input.indexOf('}', pos + 1);
            if (newPosEnd > newPosStart && input[newPosEnd - 1] == 'd' && input[newPosEnd + 1] == 'p') {
                pos = newPosEnd;

                etext = input.mid(newPosStart - 1, newPosEnd - newPosStart + 3);
                if (!etext.isEmpty()) {
                    auto decodedText = line.mid(newPosStart + 2, newPosEnd - newPosStart - 3);
                    line = line.replace(etext, QString(PrivateData::decode(decodedText.toStdString()).c_str()));
                    isReplaced = true;
                }
            }
        }
    } while(newPosStart > 0 && newPosEnd > 0);
    return isReplaced ? line.toLatin1() : input;
}
} //unnamed namespace

void Analaizer::update(QByteArray &line)
{
    QString text(line);
    if (!text.contains("p{d") && !text.contains("d}p")) {
        return;
    }
    auto index = getPayloadSizeIndex(line);
    auto newPayload = updatePayload(line.mid(index + 2));
    auto header = line.mid(0, index + 1);
    auto delta = newPayload.size()- getPayloadSize(line) + 1;
    if (delta > 0) {
        header[index] += delta;
        header[GetLengthIndex(line)] += delta;
    }
    line.clear();
    line = header + '\0' + newPayload;
}
