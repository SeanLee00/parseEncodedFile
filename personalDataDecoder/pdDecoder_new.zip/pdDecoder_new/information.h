#pragma once

#include <string>

class Information final
{
public:
    Information() = default;
    ~Information() = default;

    void showIsEmpty();
    void showHelp();
    void showIncorrect(const std::string &option);
    void showTheory();
};
