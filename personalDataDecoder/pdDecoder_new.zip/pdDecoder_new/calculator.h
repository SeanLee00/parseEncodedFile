#pragma once

#include <functional>
#include <string>

class Calculator
{
public:
    Calculator(const std::string &option);

    std::string calculate(const std::string &text);

private:
    std::function<std::string(const std::string&)> m_calculate;
};
