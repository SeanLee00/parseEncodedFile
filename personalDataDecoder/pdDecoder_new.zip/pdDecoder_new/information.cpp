#include "information.h"

#include <iostream>
#include <string>

void Information::showIsEmpty()
{
    std::cout << "Please add necessary options:" << std::endl;
    std::cout << "./pdDecoder " << " -[OPTION] parameters" << std::endl;
    std::cout << "For more detail info please use --help (-h)" << std::endl;
}

void Information::showHelp()
{
    std::cout << "OPTIONS:" << std::endl;
    std::cout << "-e    - encode text or number. Example ./pdDecoder -e 'Personal data' -> Result encoded text" << std::endl;
    std::cout << "-d    - decode text or number. Example ./pdDecoder -d 'Encoded data' ->  Result decoded personal data" << std::endl;
    std::cout << "-m    - encode/decode method description" << std::endl;
    std::cout << "-f    - decode personal data *.dlt log file. Example ./pdDecoder -f filename.dlt ->  Result decoded filename_decoded.dlt" << std::endl;
}

void Information::showIncorrect(const std::string &option)
{
    std::cout << "Option: " << option << " is incorrect." << std::endl;
}

void Information::showTheory()
{
    std::cout << "Not implemented yet. Still in progress." << std::endl;
}
