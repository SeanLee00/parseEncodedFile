#include "separator.h"
#include <QDebug>

QVector<QByteArray> Separator::separate(const QByteArray &array)
{
    QVector<QByteArray> result;
    int pos = 0;
    int index = 0;
    do {
        index = array.indexOf(QByteArrayView("DLT"), pos + 3);
        result.push_back(array.mid(pos, index - pos - 1));
        if (index > 0) {
            pos = index - 1;
        }
    } while (index > 0);
    return result;
}
