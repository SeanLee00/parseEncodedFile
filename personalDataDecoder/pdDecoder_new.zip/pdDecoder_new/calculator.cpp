#include "calculator.h"
#include "PrivateData.h"
#include "filedecoder.h"
#include <map>

namespace {
static const std::map<std::string, std::function<std::string(const std::string&)>> smap{
    {"-e", [](const std::string &text){
        PrivateData pd(text);
        return pd.encodedText();
    }},
    {"-d", [](const std::string &text){
        return PrivateData::decode(text);
    }},
    {"-f", [](const std::string &text){
        FileDecoder decoder;
        return decoder.decode(text);
    }}
};
} // unnamed namespace

Calculator::Calculator(const std::string &option)
    : m_calculate(smap.find(option)->second)
{

}

std::string Calculator::calculate(const std::string &text)
{
    return m_calculate(text);
}
