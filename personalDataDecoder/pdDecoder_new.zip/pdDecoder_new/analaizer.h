#pragma once

#include <QByteArray>

class Analaizer
{
public:
    Analaizer() = default;

    void update(QByteArray&line);
};
