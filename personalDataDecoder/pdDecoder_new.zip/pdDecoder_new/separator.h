#pragma once

#include <QVector>
#include <QByteArray>

class Separator final
{
public:
    Separator() = default;
    ~Separator() = default;
    QVector<QByteArray> separate(const QByteArray &array);
};
