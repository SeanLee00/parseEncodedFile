#include "application.h"

int main(int argc, char *argv[])
{
    Application app(argc > 1 ? argv[1] : "", argc > 2 ? argv[2] : "");
    return app.exec();
}

