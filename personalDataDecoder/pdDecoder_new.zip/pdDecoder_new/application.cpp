#include "application.h"
#include "information.h"
#include "calculator.h"
#include <iostream>
#include <map>
#include <set>

Application::Application(const std::string &option, const std::string &parameter)
    : m_option(option)
    , m_parameter(parameter)
{

}

int Application::exec()
{
    Information info;
    if (m_option.empty()) {
        info.showIsEmpty();
        return 0;
    }

    if (m_option == "--help" || m_option == "-h") {
        info.showHelp();
        return 0;
    }

    static const std::set<std::string> options{"-e", "-d", "-m", "-f"};
    if (options.find(m_option) == options.end()) {
        info.showIncorrect(m_option);
        return 0;
    }
    if (m_option == "-m") {
        info.showTheory();
        return 0;
    }

    Calculator calculator(m_option);
    auto result = calculator.calculate(m_parameter);

    static const std::map<std::string, std::string> smap{
        {"-e", "(encoded)"},
        {"-d", "(decoded)"},
        {"-f", "(filename)"}
    };
    std::cout << "Result " << smap.find(m_option)->second <<  ": " << result << std::endl;
    return 0;
}

