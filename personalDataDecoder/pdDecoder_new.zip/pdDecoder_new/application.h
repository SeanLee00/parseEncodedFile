#pragma once

#include <string>

class Application
{
public:
    Application(const std::string &option, const std::string &parameter);

    int exec();
private:
    std::string m_option;
    std::string m_parameter;
};
