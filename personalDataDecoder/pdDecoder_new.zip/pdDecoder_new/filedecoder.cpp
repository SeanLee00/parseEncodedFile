#include "analaizer.h"
#include "filedecoder.h"
#include "separator.h"

#include <QFile>

std::string FileDecoder::decode(const std::string &filename)
{
    QString fileName(filename.c_str());
    auto params = fileName.split(".");
    fileName = params[0];
    if (params[1] != "dlt") {
        return "It is not log file:" + filename;
    }
    QFile file_in(QString("%1.dlt").arg(fileName));
    if (!file_in.open(QIODevice::ReadOnly))
        return "Could not open " + filename + ".dlt";

    QFile file_out(QString("%1_decode.dlt").arg(fileName));
    if (!file_out.open(QIODevice::WriteOnly))
        return "Could not create " + filename + "_decode.dlt";

    QByteArray in = file_in.readAll();
    Separator separator;
    auto values = separator.separate(in);
    QByteArray out;
    Analaizer analizer;
    for (auto &line: values) {
        analizer.update(line);
        out += line;
    }
    out += '\0';
    file_out.write(out);
    return filename + "_decode.dlt";
}
