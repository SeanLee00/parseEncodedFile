#pragma once

#include<string>

class PrivateData final
{
public:
    PrivateData(const std::string &text);
    PrivateData(long long number);
    
    ~PrivateData() = default;

    std::string encodedText() const { return m_value.second; }
    std::string decodedText() const { return m_value.first; }
    long long getNumber(bool *isOk = nullptr) const;
   
    static std::string decode(const std::string &text, bool *isOk = nullptr);
    
private:
    bool m_isNumber = false;
    std::pair<std::string, std::string> m_value;
};
