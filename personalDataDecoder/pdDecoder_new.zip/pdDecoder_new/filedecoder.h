#pragma once

#include <iostream>

class FileDecoder
{
public:
    FileDecoder() = default;
    std::string decode(const std::string &filename);
};
