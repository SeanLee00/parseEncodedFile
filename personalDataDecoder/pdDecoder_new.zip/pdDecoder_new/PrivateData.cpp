#include "PrivateData.h"
#include <algorithm>
#include <stdexcept>
#include <string>
#include <map>
#include <regex>

#include <iostream>

namespace Shifter 
{
    std::string left(const std::string &text) {
        return {text.substr(5, text.size() - 5) + text.substr(0, 5)};
    }
    
    std::string right(const std::string &text) {
        std::string result;
        if (text.size() < 5) {
            auto shifter = 5 - text.size();
            result = text.substr(text.size() - shifter, shifter) + text.substr(0, text.size() - shifter);
        } else {
            result = text.substr(text.size() - 5, 5) + text.substr(0, text.size() - 5);
        }
        return result;
    }    
}

namespace Base64 
{
    std::string encode(const std::string &text)
    {
        auto base64_chars{"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"};
        auto trailing_char{'='};

        std::string result;
        unsigned int pos = 0;
        while (pos < text.size()) 
        {
            result.push_back(base64_chars[(text[pos + 0] & 0xfc) >> 2]);
            if (pos + 1  < text.size()) 
            {
                result.push_back(base64_chars[((text[pos + 0] & 0x03) << 4) + ((text[pos + 1] & 0xf0) >> 4)]);
                if (pos + 2 < text.size()) 
                {
                    result.push_back(base64_chars[((text[pos + 1] & 0x0f) << 2) + ((text[pos + 2] & 0xc0) >> 6)]);
                    result.push_back(base64_chars[  text[pos + 2] & 0x3f]);
                } 
                else 
                {
                    result.push_back(base64_chars[(text[pos + 1] & 0x0f) << 2]);
                    result.push_back(trailing_char);
                }
            } 
            else 
            {
                result.push_back(base64_chars[(text[pos + 0] & 0x03) << 4]);
                result.push_back(trailing_char);
                result.push_back(trailing_char);
            }

            pos += 3;
        }
        return Shifter::left(result);
    }

    static unsigned int pos_of_char(const unsigned char chr) 
    {
        if (chr >= 'A' && chr <= 'Z') {
            return chr - 'A';
        } else if (chr >= 'a' && chr <= 'z') {
            return chr - 'a' + ('Z' - 'A') + 1;
        } else if (chr >= '0' && chr <= '9') {
            return chr - '0' + ('Z' - 'A') + ('z' - 'a') + 2;
        } else if (chr == '+' || chr == '-') {
            return 62;
        } else if (chr == '/' || chr == '_') {
            return 63;
        } else {
            throw std::runtime_error("Input is not valid base64-encoded data.");
        }
    }
    
    std::string decode(const std::string &initialText)
    {
        if (initialText.empty()) { 
            return std::string();
        }

        size_t pos = 0;
        std::string result;
        auto text{Shifter::right(initialText)};
        while (pos < text.size()) 
        {
            size_t pos_of_char_1 = pos_of_char(text.at(pos + 1));
            result.push_back(((pos_of_char(text.at(pos + 0))) << 2) + ((pos_of_char_1 & 0x30 ) >> 4));
            if ((pos + 2 < text.size()) &&
                text.at(pos+2) != '=' &&
                text.at(pos+2) != '.'
            )
            {
                unsigned int pos_of_char_2 = pos_of_char(text.at(pos + 2) );
                result.push_back(((pos_of_char_1 & 0x0f) << 4) + ((pos_of_char_2 & 0x3c) >> 2));
                if ((pos + 3 < text.size()) &&
                    text.at(pos+3) != '=' &&
                    text.at(pos+3) != '.'
                ) {
                    result.push_back(((pos_of_char_2 & 0x03 ) << 6) + pos_of_char(text.at(pos + 3)));
                }
            }
            pos += 4;
        }
        return result;
    }    
}

namespace Number 
{
    std::string encode(const std::string &text)
    {
    	static const std::map<char, char> smap{{'0','Z'},{'1','A'},{'2','%'},{'3','Q'},{'4','S'},{'5','#'},{'6','R'},{'7','E'},{'8','^'},{'9','&'}};
    	std::string result;
    	for (const auto &item : text) {
    	    result.push_back(smap.find(item)->second);
    	}
        return Shifter::left(result);
    }
    
    std::string decode(const std::string &text)
    {
    	std::string result;
    	static const std::map<char, char> smap{{'Z','0'},{'A','1'},{'%','2'},{'Q','3'},{'S','4'},{'#','5'},{'R','6'},{'E','7'},{'^','8'},{'&','9'}};
    	std::string value{Shifter::right(text)};
    	for (const auto &item : value) {
            auto it = smap.find(item);
            if (it == smap.end()) {
                throw std::runtime_error("Input is not valid number-encoded data.");
            }
    	    result.push_back(it->second);
    	}
        return result;
    }

    bool isNumber(const std::string &text)
    {
        if (text.empty()) {
            return false;
        }
        static const std::regex reg{"^[ZA%QS#RE^&]*$"};
        return std::regex_search(text, reg);
    }
}

namespace 
{
    bool checkIsNumber(const std::string &text)
    {
	    return !text.empty() && std::all_of(text.begin(), text.end(), ::isdigit);    
    }
    
    std::pair<std::string, std::string> getValue(const std::string &text, bool &isNumber)
    {
        isNumber = checkIsNumber(text);
        return {text, isNumber ? Number::encode(text) : Base64::encode(text)};
    }
}

PrivateData::PrivateData(const std::string &text)
    : m_value(getValue(text, m_isNumber))
{

}

PrivateData::PrivateData(long long number)
    : m_value{std::to_string(number), Number::encode(std::to_string(number))}
    , m_isNumber{true}
{

}

long long PrivateData::getNumber(bool *isOk) const 
{
    if (isOk) {
        *isOk = m_isNumber;
    }
    if (!m_isNumber) {
       return 0;
    }
    return std::stoull(m_value.second);
}

std::string PrivateData::decode(const std::string &text, bool *isOk)
{
    auto result{text};
    if (isOk) {
        *isOk = true;
    }
    try {
        result = Number::isNumber(text) ? Number::decode(text) : Base64::decode(text);
    } catch(...) {
        if (isOk) {
            *isOk = false;
        }        
    }
    return result;
}

